 <!-- Chatbot  -->
 <!DOCTYPE html>
<html>
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/botman-web-widget@0/build/assets/css/chat.min.css">
    </head>
    <body>
        
    </body>
   <script>
    var botmanWidget = {
        title: 'GiGCafe',
        headerBackgroundColor: '#ff0000',
        aboutText: 'Start the conversation with Hi',
        introMessage: "WELCOME TO OUR GigCafe"
    };
    </script>
    
    <script src='https://cdn.jsdelivr.net/npm/botman-web-widget@0/build/js/widget.js'></script>
           
</html> 