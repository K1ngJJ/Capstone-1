<!-- resources/views/emails/reservationDefault.blade.php -->

<?php $__env->startComponent('mail::message'); ?>
# Your reservation status update

There has been an update to your reservation status.

Some details about the reservation...

<?php $__env->startComponent('mail::button', ['url' => 'link']); ?>
More Details
<?php echo $__env->renderComponent(); ?>

Thank you, <br>
GiGCafe
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\laragon\www\Capstone-1\gigcafe\resources\views/emails/reservationDefault.blade.php ENDPATH**/ ?>