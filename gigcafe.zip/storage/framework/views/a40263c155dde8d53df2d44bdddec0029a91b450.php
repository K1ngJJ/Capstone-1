

<?php $__env->startSection('content'); ?>
    <h2>Payment Analytics</h2>
    <canvas id="paymentChart"></canvas>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        var dates = <?php echo json_encode($paymentsByDate->pluck('date'), 15, 512) ?>;
        var amounts = <?php echo json_encode($paymentsByDate->pluck('total_amount'), 15, 512) ?>;

        var ctx = document.getElementById('paymentChart').getContext('2d');
        var chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: dates,
                datasets: [{
                    label: 'Total Payments',
                    data: amounts,
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                }
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Capstone-1\gigcafe\resources\views/analytics/payments.blade.php ENDPATH**/ ?>