<!DOCTYPE html>
<html>
<head>
    <title><?php echo e($title); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
        }
        .details, .cart-items {
            margin-bottom: 20px;
        }
        .details th, .details td, .cart-items th, .cart-items td {
            padding: 8px;
            border: 1px solid #ddd;
        }
        .details th, .cart-items th {
            background-color: #f2f2f2;
        }
        /* New style for Final Amount */
        .final-amount {
            color: white;
            background-color: red;
            font-weight: bold;
            text-align: center;
        }
        .amount {
            color: white;
            background-color: black;
            font-weight: bold;
            text-align: center;
        }
        .warning {
            background-color: orange; 
            color: white;
            border: gray;
            font-weight: bold;
            text-align: center; 
        } 
    </style>
</head>
<body>
    <div class="header">
        <h1><?php echo e($title); ?></h1>
        <p>Date: <?php echo e($date); ?></p>
    </div>

    <div class="details">
        <h2>Transaction Details</h2>
        <table width="100%">
            <!--tr>
                <th>ID</th>
                <td><?php echo e($transactions->id); ?></td>
            </tr-->
            <tr>
                <td class="warning">Order ID</td>
                <td><?php echo e($transactions->order_id); ?></td>
            </tr>
            <tr>
                <th>Date</th>
                <td><?php echo e($transactions->created_at->toDateString()); ?></td> <!-- Display date -->
            </tr>
            <tr>
                <th>Time</th>
                <td><?php echo e($transactions->created_at->toTimeString()); ?></td> <!-- Display time -->
            </tr>
             <!-- Check if order and user exist before accessing attributes -->
             <?php if(isset($transactions->order) && isset($transactions->order->user)): ?>
            <tr>
                <th>Customer</th>
                <td><?php echo e($transactions->order->user->name); ?></td>
            </tr>
            <?php endif; ?>
            <!-- Apply the new style to Final Amount -->
            <tr>
                <td class="amount">Final Amount</td>
                <td class="final-amount"><?php echo e($transactions->final_amount); ?></td>
            </tr>
        </table>
    </div>

</body>
</html>
<?php /**PATH C:\laragon\www\Capstone-1\gigcafe\resources\views/reports/generate-order-transaction-pdf.blade.php ENDPATH**/ ?>