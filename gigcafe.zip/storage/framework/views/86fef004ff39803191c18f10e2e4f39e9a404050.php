[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\laragon\www\Capstone-1\gigcafe\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>