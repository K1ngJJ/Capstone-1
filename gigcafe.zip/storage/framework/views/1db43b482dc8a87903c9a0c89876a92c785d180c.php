<?php $__env->startComponent('mail::message'); ?>

# Your reservation was fulfilled

Your reservation has been successfully fulfilled.

Some details about the reservation...

<?php $__env->startComponent('mail::button', ['url' => 'link']); ?>
More Details
<?php echo $__env->renderComponent(); ?>

Thank you, <br>
GiGCafe

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\laragon\www\Capstone-1\gigcafe\resources\views/emails/reservationFulfilled.blade.php ENDPATH**/ ?>