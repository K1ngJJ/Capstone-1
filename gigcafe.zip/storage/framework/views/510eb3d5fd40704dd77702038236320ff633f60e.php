

<?php $__env->startSection('navTheme'); ?>
<?php echo e('light'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('logoFileName'); ?>
<?php echo e(URL::asset('/images/Black Logo.png')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/flowbite.min.js"></script>
</head>
<body>
<div class="min-vh-100 d-flex align-items-start mt-5 pt-5vh">
    <div class="container">
        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="flex m-2 p-2">
                    <a href="<?php echo e(route('reservations.index')); ?>"
                       class="px-4 py-2 bg-indigo-500 hover:bg-indigo-700 rounded-lg text-white">Reservation List</a>
                </div>
                <div class="m-2 p-2 bg-slate-100 rounded">
                    <div class="space-y-8 divide-y divide-gray-200 w-1/2 mt-10">
                        <form method="POST" action="<?php echo e(route('reservations.update', $reservation->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="sm:col-span-6">
                                <label for="first_name" class="block text-sm font-medium text-gray-700"> First Name
                                </label>
                                <div class="mt-1">
                                    <input type="text" id="first_name" name="first_name"
                                           value="<?php echo e($reservation->first_name); ?>"
                                           class="block w-full appearance-none bg-white border border-gray-400 rounded-md py-2 px-3 text-base leading-normal transition duration-150 ease-in-out sm:text-sm sm:leading-5" />
                                </div>
                                <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-sm text-red-400"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <!-- Last Name -->
                            <div class="sm:col-span-6">
                                <label for="last_name" class="block text-sm font-medium text-gray-700"> Last Name
                                </label>
                                <div class="mt-1">
                                    <input type="text" id="last_name" name="last_name"
                                           value="<?php echo e($reservation->last_name); ?>"
                                           class="block w-full appearance-none bg-white border border-gray-400 rounded-md py-2 px-3 text-base leading-normal transition duration-150 ease-in-out sm:text-sm sm:leading-5" />
                                </div>
                                <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-sm text-red-400"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <!-- Email -->
                            <div class="sm:col-span-6">
                                <label for="email" class="block text-sm font-medium text-gray-700"> Email </label>
                                <div class="mt-1">
                                    <input type="email" id="email" name="email" value="<?php echo e($reservation->email); ?>"
                                           class="block w-full appearance-none bg-white border border-gray-400 rounded-md py-2 px-3 text-base leading-normal transition duration-150 ease-in-out sm:text-sm sm:leading-5" />
                                </div>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-sm text-red-400"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <!-- Phone Number -->
                            <div class="sm:col-span-6">
                                <label for="tel_number" class="block text-sm font-medium text-gray-700"> Phone number
                                </label>
                                <div class="mt-1">
                                    <input type="text" id="tel_number" name="tel_number"
                                           value="<?php echo e($reservation->tel_number); ?>"
                                           class="block w-full appearance-none bg-white border border-gray-400 rounded-md py-2 px-3 text-base leading-normal transition duration-150 ease-in-out sm:text-sm sm:leading-5" />
                                </div>
                                <?php $__errorArgs = ['tel_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-sm text-red-400"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <!-- Reservation Date -->
                            <div class="sm:col-span-6">
                                <label for="res_date" class="block text-sm font-medium text-gray-700">Reservation Date</label>
                                <div class="mt-1">
                                    <input type="datetime-local" id="res_date" name="res_date"
                                           value="<?php echo e($reservation->res_date ? \Carbon\Carbon::parse($reservation->res_date)->format('Y-m-d\TH:i') : ''); ?>"
                                           class="block w-full appearance-none bg-white border border-gray-400 rounded-md py-2 px-3 text-base leading-normal transition duration-150 ease-in-out sm:text-sm sm:leading-5" />
                                </div>
                                <?php $__errorArgs = ['res_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-sm text-red-400"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <!-- Guest Number -->
                            <div class="sm:col-span-6">
                                <label for="guest_number" class="block text-sm font-medium text-gray-700"> Guest Number
                                </label>
                                <div class="mt-1">
                                    <input type="number" id="guest_number" name="guest_number"
                                           value="<?php echo e($reservation->guest_number); ?>"
                                           class="block w-full appearance-none bg-white border border-gray-400 rounded-md py-2 px-3 text-base leading-normal transition duration-150 ease-in-out sm:text-sm sm:leading-5" />
                                </div>
                                <?php $__errorArgs = ['guest_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-sm text-red-400"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <!-- Service Selection -->
                            <div class="sm:col-span-6">
                                <label for="service_id" class="block text-sm font-medium text-gray-700">Service</label>
                                <div class="mt-1">
                                    <select id="service_id" name="service_id" class="form-multiselect block w-full mt-1">
                                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($service->id); ?>"
                                                    <?php echo e($service->id == $reservation->service_id ? 'selected' : ''); ?>>
                                                <?php echo e($service->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <?php $__errorArgs = ['service_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-sm text-red-400"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <!-- Package Selection -->
                            <div class="sm:col-span-6 pt-5">
                                <label for="package_id" class="block text-sm font-medium text-gray-700">Package</label>
                                <div class="mt-1">
                                    <select id="package_id" name="package_id" class="form-multiselect block w-full mt-1">
                                        <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($package->id); ?>"
                                                    <?php echo e($package->id == $reservation->package_id ? 'selected' : ''); ?>>
                                                <?php echo e($package->name); ?> (<?php echo e($package->guest_number); ?> Guests)
                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <?php $__errorArgs = ['package_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-sm text-red-400"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                           <!-- Supply Choice -->
                            <div class="sm:col-span-6">
                                <br>
                                <label for="supply_choice" class="block text-sm font-medium text-gray-700">Supply Choice</label>
                                <div class="mt-1 flex flex-row">
                                    <input type="radio" id="bring_own" name="supply_choice" value="bring_own" <?php echo e($reservation->supply_choice === 'bring_own' ? 'checked' : ''); ?> class="mr-2">
                                    <label for="bring_own">Bring Own Supplies</label>
                                    <input type="radio" id="borrow_supplies" name="supply_choice" value="borrow_supplies" <?php echo e($reservation->supply_choice === 'borrow_supplies' ? 'checked' : ''); ?> class="ml-4 mr-2">
                                    <label for="borrow_supplies">Borrow Our Supplies</label>
                                </div>
                            </div>
                            <br>
                            <!-- Inventory Supplies -->
                            <div id="inventoryFields" style="<?php echo e($reservation->supply_choice === 'borrow_supplies' ? 'display: block;' : 'display: none;'); ?>">
                                <div class="sm:col-span-6">
                                    <label for="inventory_supplies" class="block text-sm font-medium text-gray-700">Inventory Supplies</label>
                                    <?php $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="flex items-center mb-2">
                                        <input type="checkbox" id="inventory_<?php echo e($inventory->id); ?>" name="inventory_supplies[]" value="<?php echo e($inventory->id); ?>" <?php echo e(is_array($reservation->inventory_supplies) && in_array($inventory->id, $reservation->inventory_supplies) ? 'checked' : ''); ?> class="mr-2">
                                            <label for="inventory_<?php echo e($inventory->id); ?>"> <?php echo e($inventory->name); ?></label>
                                            <input type="number" id="quantity_<?php echo e($inventory->id); ?>" name="inventory_quantities[]" value="<?php echo e(is_object($reservation->inventory_supplies) ? $reservation->inventory_supplies->where('id', $inventory->id)->first()->pivot->quantity ?? 1 : 1); ?>" class="ml-4 w-8 border border-gray-400 rounded-md py-1 px-2">

                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                            <!-- Status -->
                            <div class="sm:col-span-6 pt-5">
                                <label for="status" class="block text-sm font-medium text-gray-700">Status</label>
                                <div class="mt-1">
                                    <select id="status" name="status" class="form-multiselect block w-full mt-1">
                                        <?php $__currentLoopData = \App\Enums\ReservationStatus::cases(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($status->value); ?>" <?php echo e($status->value === $reservation->status ? 'selected' : ''); ?>>
                                                <?php echo e($status->value); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-sm text-red-400"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <!-- Submit Button -->
                            <div class="mt-6 p-4">
                                <button type="submit"
                                        class="px-4 py-2 bg-indigo-500 hover:bg-indigo-700 rounded-lg text-white">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const bringOwnRadio = document.getElementById('bring_own');
        const borrowSuppliesRadio = document.getElementById('borrow_supplies');
        const inventoryFields = document.getElementById('inventoryFields');

        function toggleInventoryFields() {
            inventoryFields.style.display = borrowSuppliesRadio.checked ? 'block' : 'none';
        }

        toggleInventoryFields();

        bringOwnRadio.addEventListener('change', function () {
            toggleInventoryFields();
        });

        borrowSuppliesRadio.addEventListener('change', function () {
            toggleInventoryFields();
        });

        // Get the supply choice value from the database
        const supplyChoice = "<?php echo e($reservation->supply_choice); ?>";

        // Set the appropriate radio button based on the database value
        if (supplyChoice === 'bring_own') {
            bringOwnRadio.checked = true;
        } else {
            borrowSuppliesRadio.checked = true;
        }

        // If the supply choice is to borrow supplies, populate the inventory supplies and quantities
        if (supplyChoice === 'borrow_supplies') {
            const inventorySupplies = <?php echo json_encode($reservation->inventory_supplies); ?>;
            const inventoryQuantities = <?php echo json_encode($reservation->inventory_quantities); ?>;

            inventorySupplies.forEach((supplyId, index) => {
                const inventoryCheckbox = document.getElementById('inventory_' + supplyId);
                if (inventoryCheckbox) {
                    inventoryCheckbox.checked = true;
                    const quantityInput = document.getElementById('quantity_' + supplyId);
                    if (quantityInput) {
                        quantityInput.value = inventoryQuantities[index];
                    }
                }
            });
        }
    });
</script>

</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Capstone-1\gigcafe\resources\views/reservations/edit.blade.php ENDPATH**/ ?>