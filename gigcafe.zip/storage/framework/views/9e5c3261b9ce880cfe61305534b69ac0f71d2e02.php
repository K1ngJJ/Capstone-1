

<?php $__env->startSection('links'); ?>
    <link href="<?php echo e(asset('css/accountCreation.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bodyID'); ?>
<?php echo e('accountCreation'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('navTheme'); ?>
<?php echo e('light'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('logoFileName'); ?>
<?php echo e(URL::asset('/images/Black Logo.png')); ?><?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<style>

.btn-danger {
    background-color: black; 
    color: white;
    border: gray;
}

.btn-complete {
    background-color: red; 
    color: white;
    border: gray;
} 

.btn-warning {
    background-color: orange; 
    color: white;
    border: gray;
} 

.btn-success {
    color: white;
} 
.btn-success:hover {
    background-color: white;
    color: black;
}



</style>
<div class="pt-18vh">
    <section class="container mt-5 mt-md-0 pt-5 pt-md-0">
        <div class="row d-flex justify-content-center" id="top-bar">
            <div class="col-md-2" id="title">
                <label>Manage Accounts</label>
            </div>
        </div>

        <div class="container">
            <h2 class="mb-4">Accounts</h2>
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col"></th>
                        <th scope="col"></th>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Contact No.</th>
                        <th scope="col">Status</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($users->id); ?></th>
                        <td><?php echo e($users->role); ?></td>
                        <td></td>
                        <td><?php echo e($users->name); ?></td>
                        <td><?php echo e($users->email); ?></td>
                        <td><?php echo e($users->mobile_number); ?></td>
                        <td>
                            <a href="<?php echo e(route('user.update', ['id' => $users->id])); ?>" class="btn btn-success btn-<?php echo e($users->status ? 'success' : 'danger'); ?>">
                                <?php echo e($users->status ? 'Enable' : 'Disable'); ?>

                            </a>
                        </td>
                        <td>
                            <button type="button" class="btn btn-outline-success" data-bs-toggle="modal" data-bs-target="#editModal<?php echo e($users->id); ?>">Edit</button>
                            <button type="button" class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo e($users->id); ?>">Delete</button>
                        </td>
                    </tr>
                    <!-- Edit Modal -->
                    <div class="modal fade" id="editModal<?php echo e($users->id); ?>" tabindex="-1" aria-labelledby="editModalLabel<?php echo e($users->id); ?>" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="editModalLabel<?php echo e($users->id); ?>">Edit Account</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form action="<?php echo e(route('user.saveChanges', ['id' => $users->id])); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div class="mb-3">
                                            <label for="name" class="form-label">Name</label>
                                            <input type="text" class="form-control" id="name" name="name" value="<?php echo e($users->name); ?>">
                                        </div>
                                        <div class="mb-3">
                                            <label for="email" class="form-label">Email</label>
                                            <input type="email" class="form-control" id="email" name="email" value="<?php echo e($users->email); ?>">
                                        </div>
                                        <div class="mb-3">
                                            <label for="mobile_number" class="form-label">Contact Number</label>
                                            <input type="text" class="form-control" id="mobile_number" name="mobile_number" value="<?php echo e($users->mobile_number); ?>">
                                        </div>
                                    
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Cancel</button>
                                            <button type="submit" class="btn btn-complete">Save changes</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Edit Modal -->


                    <!-- Delete Modal -->
                    <div class="modal fade" id="deleteModal<?php echo e($users->id); ?>" tabindex="-1" aria-labelledby="deleteModalLabel<?php echo e($users->id); ?>" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="deleteModalLabel<?php echo e($users->id); ?>">Delete Account</h5>
                                   
                                </div>
                                <div class="modal-body">
                                    Are you sure you want to delete this account?
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Cancel</button>
                                    <form action="<?php echo e(route('user.delete', ['id' => $users->id])); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Delete Modal -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </section>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Capstone-1\gigcafe\resources\views/accounts/index.blade.php ENDPATH**/ ?>