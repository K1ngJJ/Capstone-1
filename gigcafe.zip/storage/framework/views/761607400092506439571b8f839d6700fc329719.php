<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\Capstone-1\gigcafe\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>