<!DOCTYPE html>
<html>
<head>
    <title><?php echo e($title); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
        }
        .details {
            margin-bottom: 20px;
        }
        .details th, .details td {
            padding: 8px;
            border: 1px solid #ddd;
        }
        .details th {
            background-color: #f2f2f2;
        }
        .inventory {
            margin-top: 20px;
        }
        .inventory th, .inventory td {
            padding: 8px;
            border: 1px solid #ddd;
        }
        .inventory th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1><?php echo e($title); ?></h1>
        <p>Date: <?php echo e($date); ?></p>
    </div>

    <div class="details">
        <h2>Reservation Details</h2>
        <table width="100%">
            <tr>
                <th>ID</th>
                <td><?php echo e($reservation->id); ?></td>
            </tr>
            <tr>
                <th>Name</th>
                <td><?php echo e($reservation->first_name); ?> <?php echo e($reservation->last_name); ?></td>
            </tr>
            <tr>
                <th>Telephone</th>
                <td><?php echo e($reservation->tel_number); ?></td>
            </tr>
            <tr>
                <th>Email</th>
                <td><?php echo e($reservation->email); ?></td>
            </tr>
            <tr>
                <th>Status</th>
                <td><?php echo e($reservation->status); ?></td>
            </tr>
            <tr>
                <th>Reservation Date</th>
                <td><?php echo e($reservation->res_date->format('m/d/Y')); ?></td>
            </tr>
            <tr>
                <th>Guest Number</th>
                <td><?php echo e($reservation->guest_number); ?></td>
            </tr>
            <tr>
                <th>Event</th>
                <td><?php echo e($reservation->service ? $reservation->service->name : 'No event associated'); ?></td>
            </tr>
            <tr>
                <th>Service Type</th>
                <td><?php echo e($reservation->cateringoption ? $reservation->cateringoption->name : 'No service associated'); ?></td>
            </tr>
            <tr>
                <th>Package</th>
                <td><?php echo e($reservation->service ? $reservation->service->name : 'No service associated'); ?></td>
            </tr>
            <tr>
                <th>Supplies</th>
                <td><?php echo e($reservation->inventory_supplies ? $reservation->inventory_supplies : 'No supplies associated'); ?></td>
            </tr>
            <tr>
                <th>Payment Method</th>
                <td class="info-value mt-2 px-2 alert 
                        <?php echo e($reservation->payment_status == 'Fully Payment' ? 'alert-success' : ($reservation->payment_status == 'Down Payment' ? 'alert-warning' : ($reservation->payment_status == 'Pay in Restaurant' ? 'alert-failed' : ''))); ?>">
                    <?php echo e($reservation->payment_status); ?>

                </td>
            </tr>
        </table>
    </div>

    <!--div class="inventory">
    <h2>Inventory Supplies</h2>
    <table width="100%">
        <tr>
            <th>Item</th>
            <th>Quantity Reserved</th>
            <th>Price</th>
            <th>Total Price</th>
        </tr>
        <?php $__currentLoopData = $inventorySupplies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($inventory->name); ?></td>
                <td><?php echo e($inventory->pivot->quantity); ?></td>
                <td><?php echo e($inventory->price); ?></td>
                <td><?php echo e($inventory->price * $inventory->pivot->quantity); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div-->



</body>
</html>
<?php /**PATH C:\laragon\www\Capstone-1\gigcafe\resources\views/reports/generate-reservation-pdf.blade.php ENDPATH**/ ?>