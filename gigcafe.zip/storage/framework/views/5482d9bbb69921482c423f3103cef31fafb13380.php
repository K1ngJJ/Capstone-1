<?php $__env->startComponent('mail::message'); ?>

# Your reservation was approved

We are pleased to inform you that your reservation has been approved.

Some details about the reservation...

<?php $__env->startComponent('mail::button', ['url' => 'link']); ?>
More Details
<?php echo $__env->renderComponent(); ?>

Thank you, <br>
GiGCafe

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\laragon\www\Capstone-1\gigcafe\resources\views/emails/reservationApproved.blade.php ENDPATH**/ ?>