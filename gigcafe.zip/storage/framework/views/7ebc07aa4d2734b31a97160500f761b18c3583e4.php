

<?php $__env->startSection('links'); ?>
    <link href="<?php echo e(asset('css/order.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bodyID'); ?>
<?php echo e('kitchenOrder'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('navTheme'); ?>
<?php echo e('light'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('logoFileName'); ?>
<?php echo e(URL::asset('/images/Black Logo.png')); ?><?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<?php if(!$firstOrder): ?>
<!-- no active orders -->
<section class="empty-order min-vh-100 flex-center pt-5">
    <div class="container d-flex flex-column justify-content-center align-items-center">
        <div class="hero-wrapper">
            <img src="<?php echo e(URL::asset('/images/empty_order.svg')); ?>" alt="">
        </div>
        <h3 class="mt-4 mb-2">No Orders Yet.</h3>
        <p class="text-muted">No customers with unfulfilled orders for now...</p>
        <div class="d-flex mt-3">
            <a href="<?php echo e(route('previousOrder')); ?>" class="primary-btn mx-3">Previous Orders</a>
            <a href="<?php echo e(route('dashboard')); ?>" class="primary-btn mx-3">View Dashboard</a>
        </div>
    </div>
</section>
<?php else: ?>
<!-- todo - session success stuff -->
<section class="first-order d-flex">
    <div class="container">
        <div class="order-metadata mb-4">
            <div class="d-flex">
                <h2>ORDER #<?php echo e($firstOrder->id); ?></h2>
                <?php if($firstOrder->completed): ?>
                <div class="mx-5 px-3 alert alert-success">
                    Fulfilled
                </div>
                <?php else: ?>
                <div class="mx-5 px-3 alert alert-warning">
                    Not fulfilled
                </div>
                <?php endif; ?>
            </div>
            <div class="d-flex">
                <p class="text-muted"><?php echo e($firstOrder->getOrderDate()); ?></p>
                <p class="px-3 text-muted"><?php echo e($firstOrder->getOrderTime()); ?></p>
            </div>
        </div>

        <div class="order-cart p-4 mb-5">
            <h3 class="pb-4 px-2">Customer's cart</h3>
            <div class="flex-center flex-column order-cart-items">
            <?php $__currentLoopData = $firstOrder->cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="order-cart-item d-flex justify-content-around">
                    <div class="food-img-wrapper">
                        <img src="<?php echo e(asset('menuImages/' . $orderItem->menu->image)); ?>" class="order-food">                      
                    </div>
                    <div class="food-desc-wrapper">
                        <div class="d-flex justify-content-between">
                            <h5><?php echo e($orderItem->menu->name); ?></h5>
                            <div class="food-status-wrapper">
                            <?php if($orderItem->fulfilled): ?>
                                <form action="<?php echo e(route('orderStatusUpdate', $orderItem->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <button class="primary-btn px-3 unfulfill">Unfulfill</button>
                                </form>
                            <?php else: ?>
                                <form action="<?php echo e(route('orderStatusUpdate', $orderItem->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <button class="primary-btn px-3 fulfill">Fulfill</button>
                                </form>                                
                            <?php endif; ?>
                            </div>
                        </div>
                        <div class="mobile d-flex pt-2">
                            <p class="price"><?php echo e(number_format($orderItem->menu->price, 2)); ?></p>
                            <p class="quantity">x<?php echo e($orderItem->quantity); ?></p>
                            <p class="cart-item-total">₱ <?php echo e(number_format($orderItem->menu->price * $orderItem->quantity, 2)); ?></p>        
                        </div>
                        <p class="text-muted desktop w-75"><?php echo e($orderItem->menu->description); ?></p>
                    </div>
                    <p class="price desktop">₱ <?php echo e(number_format($orderItem->menu->price, 2)); ?></p>
                    <p class="quantity desktop">x<?php echo e($orderItem->quantity); ?></p>
                    <p class="cart-item-total desktop">₱ <?php echo e(number_format($orderItem->menu->price * $orderItem->quantity, 2)); ?></p>
                </div>
                <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <?php if(!$activeOrders->count()): ?>
        <div class="d-flex justify-content-center">
            <a href="<?php echo e(route('previousOrder')); ?>" class="primary-btn">Previous Orders</a>
        </div>
        <?php endif; ?>

    </div>
</section>
<?php endif; ?>

<?php if($activeOrders->count()): ?>
<section class="kitchen-active-orders">
    <div class="container">
        <h2 class="mb-4">Active Orders</h2>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th scope="col">Order ID</th>
                    <th scope="col">Date</th>
                    <th scope="col">Time</th>
                    <th scope="col">Final Price</th>
                    <th scope="col">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $activeOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($firstOrder->id == $order->id): ?>
                    <tr class="table-active">
                    <?php else: ?>
                    <tr>
                    <?php endif; ?>
                        <th scope="row"><a href="<?php echo e(route('specificOrder', $order->id)); ?>">#<?php echo e($order->id); ?></a></th>
                        <td><?php echo e($order->getOrderDate()); ?></td>
                        <td><?php echo e($order->getOrderTime()); ?></td>
                        <td>₱ <?php echo e($order->getTotalFromScratch()); ?></td>
                        <td>
                            <?php if($order->completed): ?>
                                <div class="px-3 alert alert-success">
                                    Fulfilled
                                </div>  
                            <?php else: ?>
                                <div class="px-3 alert alert-warning">
                                    Not fulfilled
                                </div>  
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="mt-5 d-flex justify-content-between">
            <a href="<?php echo e(route('previousOrder')); ?>" class="primary-btn">Previous Orders</a>
            <?php echo e($activeOrders->links()); ?>

        </div>
    </div>
</section>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make(( auth()->user()->role == 'customer' ) ? 'layouts.app' : 'layouts.backend' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Capstone-1\gigcafe\resources\views/kitchenOrder.blade.php ENDPATH**/ ?>