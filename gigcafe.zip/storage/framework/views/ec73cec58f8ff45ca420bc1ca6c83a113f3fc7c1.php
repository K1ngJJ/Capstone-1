

<?php $__env->startSection('links'); ?>
    <link href="<?php echo e(asset('css/order.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bodyID'); ?>
<?php echo e('cart'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('navTheme'); ?>
<?php echo e('light'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('logoFileName'); ?>
<?php echo e(URL::asset('/images/Black Logo.png')); ?><?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<section class="cart" style="margin-top: 20vh;">
    <div class="container">
        <h2 class="d-flex justify-content-center">CART</h2>

        <?php if(session('success')): ?>
        <div class="alert alert-success fixed-bottom" role="alert" style="width:500px;left:30px;bottom:20px">
            <?php echo e(session('success')); ?>

        </div>
        <?php elseif(session('error')): ?>
        <div class="alert alert-warning fixed-bottom" role="alert" style="width:500px;left:30px;bottom:20px">
            <?php echo e(session('error')); ?>

        </div>
        <?php endif; ?>
        <?php if($cartItems->count()): ?>

            <div class="container py-5">
                <div class="card col-md-6 col-12 offset-md-3">
                    <div class="card-body">
                        <h4 class="card-title mb-5 mx-2">GigCafe Wishlist <span class="text-secondary h5">- <?php echo e($cartItems->count()); ?> Items</span></h4>

                        <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="w-100 px-3 d-flex align-items-center py-3">
                                <div class="col-2">
                                    <img src="<?php echo e(asset('menuImages/' . $item->menu->image)); ?>" alt="cart item image" class="img-fluid">
                                </div>
                                <div class="col-6 px-4">
                                    <h5 class="text-dark"><?php echo e($item->menu->name); ?></h5>
                                    <h5 class="text-secondary">₱ <?php echo e($item->menu->price * $item->quantity); ?></h5>
                                </div>
                                <div class="col-4 d-flex align-items-baseline justify-content-end">
                                    <!-- Decrement button -->
                                    <form action="<?php echo e(route('cartUpdate', $item)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <input type="hidden" name="cartAction" value="-">
                                        <button type="submit" class="btn btn-outline-secondary">-</button>
                                    </form>
                                    <!-- Quantity -->
                                    <h5 class="mx-4"><?php echo e($item->quantity); ?></h5>
                                    <!-- Increment button -->
                                    <form action="<?php echo e(route('cartUpdate', $item)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <input type="hidden" name="cartAction" value="+">
                                        <button type="submit" class="btn btn-outline-secondary">+</button>
                                    </form>   
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex justify-content-between px-3 mt-5">
                            <h5 class="text-dark">Subtotal</h5>
                            <h5 class="text-dark">₱ <?php echo e($subtotal); ?></h5>
                        </div>

                        <!-- CHECKOUT ALONG WITH DISCOUNT CODE APPLICATION START -->
                        <form action="<?php echo e(route('cartCheckout')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="d-flex flex-column px-3 mt-5 col-12 align-items-center">
                                <h5 class="text-secondary">Discount Code</h5>
                                <input type="text" class="form-control mt-3" name="discountCode" id="discountCode" placeholder="Place your discount code here...">
                            </div>

                            <h5 class="text-secondary mt-5 text-center">Order Date and Time</h5>
                            <div class="d-flex flex-column mt-4 px-3">
                                <!-- Select Date time (only applicable for dine in / take away, not dine in now) -->
                                <!-- Perform validation to ensure they don't select time that has passed -->
                                <input class="form-control <?php $__errorArgs = ['dateTime'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="dateTime" type="datetime-local" value="<?php echo e(old('dateTime')); ?>" required>
                                <?php $__errorArgs = ['dateTime'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Dine in / dine in now / take away ==> radio -->
                            <h5 class="text-secondary mt-5 text-center">Order Type</h5>
                            <div class="d-flex justify-content-center mt-4">
                                <div class="form-check form-check-inline">
                                    <input value="Dine-In" class="form-check-input <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> h5" type="radio" name="type" id="Dine-InRadio">
                                    <label class="form-check-label" for="Dine-InRadio">
                                        Dine In
                                    </label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input value="Take-Out" class="form-check-input <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> h5" type="radio" name="type" id="Take-OutRadio">
                                    <label class="form-check-label" for="Take-OutRadio">
                                        Take Out 
                                    </label>
                                    <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                                                        <!-- perhaps add a confirmation during checkout process - like a popup or smtg -->
                            <button type="submit" class="primary-btn mt-5 w-100">Checkout</button>
                        </form>
                        <!-- CHECKOUT END -->
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="d-flex justify-content-center">
                <div class="col-md-4 col-8">
                    <div class="col-12 mt-5 d-flex align-items-baseline">
                        <div class="col-2 px-2">
                            <img src="./images/cart.svg" alt="cart" class="img-fluid">
                        </div>
                        <div class="col-10">
                            <h4 class="m-3">Empty Cart</h4>
                        </div>
                    </div>
                    <div class="col-12 mt-5">
                        <p class="h5">Your cart is empty currently. <span><a href="<?php echo e(route('menu')); ?>" class="h5"><u>Add item now</u></a></span></p>
                    </div>
                    <div class="col-12 mt-4">
                        <a href="<?php echo e(route('menu')); ?>"><button class="primary-btn w-100 py-2">See Menu</button></a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Capstone-1\gigcafe\resources\views/cart.blade.php ENDPATH**/ ?>