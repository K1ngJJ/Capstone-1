

<?php $__env->startSection('content'); ?>
    <h2>Reservation Analytics</h2>
    <div>
        <canvas id="reservationChart"></canvas>
    </div>

    <script>
        var dates = <?php echo json_encode($reservationsByDate->pluck('date'), 15, 512) ?>;
        var counts = <?php echo json_encode($reservationsByDate->pluck('count'), 15, 512) ?>;

        var ctx = document.getElementById('reservationChart').getContext('2d');
        var chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: dates,
                datasets: [{
                    label: 'Reservations',
                    data: counts,
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                }
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Capstone-1\gigcafe\resources\views/analytics/reservations.blade.php ENDPATH**/ ?>