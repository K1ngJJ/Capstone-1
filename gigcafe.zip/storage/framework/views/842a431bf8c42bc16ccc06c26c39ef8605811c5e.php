<!DOCTYPE html>
<html>
<head>
    <title>Transactions</title>
    <!-- Add necessary CSS and JS here -->
</head>
<body>
    <h1>Transactions</h1>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Final Amount</th>
                <th>User</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($transaction->id); ?></td>
                    <td><?php echo e($transaction->final_amount); ?></td>
                    <td><?php echo e($transaction->order->user->name); ?></td>
                    <td>
                        <a href="<?php echo e(route('order_transactions.pdf', $transaction->id)); ?>" class="btn btn-dark btn-sm" download>
                            <i class="fa fa-download"></i> Download PDF
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\laragon\www\Capstone-1\gigcafe\resources\views/order_transactions/index.blade.php ENDPATH**/ ?>