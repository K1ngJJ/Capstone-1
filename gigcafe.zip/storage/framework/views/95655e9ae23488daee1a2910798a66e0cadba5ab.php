<?php $__env->startSection('links'); ?>
    <script src="<?php echo e(asset('js/dashboard.js')); ?>" type="text/javascript"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
<?php $__env->stopSection(); ?>

<style>
/* Your existing CSS */
.notification {
    position: relative;
    display: inline-block;
}

.notification .badge {
    position: absolute;
    top: -5px;
    right: -5px;
    background: red;
    color: white;
    border-radius: 50%;
    padding: 2px 6px;
    font-size: 10px;
}

.notifications-dropdown {
    display: none;
    position: absolute;
    top: 0; /* Align with the top edge of the container */
    right: 0; /* Align with the right edge of the container */
    background-color: white;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
    width: 300px;
    font-size: 12px;
}


.notification:hover .notifications-dropdown {
    display: block;
}

.notifications-dropdown ul {
    list-style-type: none;
    padding: 0;
    margin: 0;
}

.notifications-dropdown li {
    padding: 8px;
    border-bottom: 1px solid #ddd;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.notifications-dropdown li:last-child {
    border-bottom: none;
}

.mark-as-read, .mark-all-link {
    color: #007bff;
    text-decoration: none;
}

.mark-as-read:hover, .mark-all-link:hover {
    text-decoration: underline;
}

.mark-all-link {
    display: block;
    text-align: center;
    padding: 8px;
    font-size: 12px;
    cursor: pointer;
}
</style>

<div class="notification">
    <i class="fa fa-bell" style="font-size: 35px;"></i>
    <?php if(auth()->user()->unreadNotifications->count()): ?>
        <span class="badge"><?php echo e(auth()->user()->unreadNotifications->count()); ?></span>
    <?php endif; ?>
    <div class="notifications-dropdown">
        <ul>
            <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <?php if(auth()->user()->role === 'admin'): ?>
                <?php $__empty_1 = true; $__currentLoopData = auth()->user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="alert alert-success" role="alert">
                        [<?php echo e($notification->created_at); ?>] Customer <?php echo e($notification->data['name']); ?> (<?php echo e($notification->data['email']); ?>) has just registered.
                        <form action="<?php echo e(route('markNotification')); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($notification->id); ?>">
                            <button type="submit" class="btn btn-link p-0 mark-as-read">
                                Mark as read
                            </button>
                        </form>
                    </div>

                    <?php if($loop->last): ?>
                        <form action="<?php echo e(route('markNotification')); ?>" method="POST" id="mark-all-form">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-link mark-all-link">
                                Mark all as read
                            </button>
                        </form>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    There are no new notifications
                <?php endif; ?>
            <?php else: ?>
                You are logged in!
            <?php endif; ?>
        </ul>
    </div>
</div>
<?php /**PATH C:\laragon\www\Capstone-1\gigcafe\resources\views/partials/notification.blade.php ENDPATH**/ ?>