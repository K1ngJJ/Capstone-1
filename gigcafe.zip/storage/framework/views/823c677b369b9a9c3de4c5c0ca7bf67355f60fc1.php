



<?php $__env->startSection('links'); ?>
    <link href="<?php echo e(asset('css/order.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bodyID'); ?>
<?php echo e('order'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('navTheme'); ?>
<?php echo e('light'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('logoFileName'); ?>
<?php echo e(URL::asset('/images/Black Logo.png')); ?><?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<section class="empty-order min-vh-100 pt-5 flex-center">
    <div class="container d-flex flex-column justify-content-center align-items-center">
        <div class="hero-wrapper">
            <img src="<?php echo e(URL::asset('/images/empty_order.svg')); ?>" alt="">
        </div>
        <h3 class="mt-4 mb-2">404</h3>
        <p class="text-muted">Oops, it seems this page doesn't exist...</p>
        <?php if(auth()->guard()->guest()): ?>
            <a href="<?php echo e(route('home')); ?>" class="primary-btn mt-3 py-2 px-3 rounded">Home</a>
        <?php else: ?>
            <?php if(auth()->user()->role == 'customer'): ?>
            <a href="<?php echo e(route('home')); ?>" class="primary-btn mt-3 py-2 px-3 rounded">Home</a>
            <?php else: ?>
            <a href="<?php echo e(route('dashboard')); ?>" class="primary-btn mt-3 py-2 px-3 rounded">Dashboard</a>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Capstone-1\gigcafe\resources\views/errors/404.blade.php ENDPATH**/ ?>