<!doctype html>
<html>
<head>
    <title>GigCafe</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/botman-web-widget/build/assets/css/chat.min.css">
    <style>
        /* Custom background color for BotMan Web Widget */
        .widget-container {
            background-color: red; /* Change to your desired color */
        }
    </style>
</head>
<body>
    
<script id="botmanWidget" src='https://cdn.jsdelivr.net/npm/botman-web-widget/build/js/chat.js'></script>
</body>
</html>
<?php /**PATH C:\laragon\www\Capstone-1\gigcafe\vendor\botman\driver-web\src\Providers/../Laravel/views/chat.blade.php ENDPATH**/ ?>