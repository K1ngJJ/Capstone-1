

<?php $__env->startSection('links'); ?>
    <link href="<?php echo e(asset('css/order.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bodyID'); ?>
<?php echo e('previousOrder'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('navTheme'); ?>
<?php echo e('light'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('logoFileName'); ?>
<?php echo e(URL::asset('/images/Black Logo.png')); ?><?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<?php if(!$discounts->count()): ?>
<!-- no previous orders -->
<section class="empty-order min-vh-100 flex-center pt-5">
    <div class="container d-flex flex-column justify-content-center align-items-center">
        <div class="hero-wrapper">
            <img src="<?php echo e(URL::asset('/images/empty_order.svg')); ?>" alt="">
        </div>
        <h3 class="mt-4 mb-2">No Discount Vouchers Yet.</h3>
        <p class="text-muted">There seems to be no discount vouchers for now...</p>
        <div class="d-flex mt-3">
            <a href="<?php echo e(route('createDiscount')); ?>" class="primary-btn mx-3">Create Discount</a>
        </div>
    </div>
</section>
<?php else: ?>
<section class="min-vh-100 d-flex align-items-start mt-5 pt-18vh">
    <div class="container">
        <div class="d-flex justify-content-between">
        <h2 class="mb-4">Discount Codes</h2>
        <a href="<?php echo e(route('createDiscount')); ?>" class="primary-btn">+ Create Discount</a>
        </div>
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th scope="col">Code</th>
                    <th scope="col">Percentage</th>
                    <th scope="col">Min Spend</th>
                    <th scope="col">Cap</th>
                    <th scope="col">Start Date</th>
                    <th scope="col">End Date</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $discounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><a href="<?php echo e(route('specificDiscount', $discount->id)); ?>">
                            <?php echo e($discount->discountCode); ?> </a></th>
                        <td><?php echo e($discount->percentage); ?>%</td>
                        <td>₱<?php echo e(number_format($discount->minSpend, 2)); ?></td>
                        <td>₱<?php echo e(number_format($discount->cap, 2)); ?></td>
                        <td><?php echo e($discount->startDate); ?></td>
                        <td><?php echo e($discount->endDate); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        
    </div>
</section>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Capstone-1\gigcafe\resources\views/discount.blade.php ENDPATH**/ ?>