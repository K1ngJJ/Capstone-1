<?php

namespace App\Enums;

enum CateringOptionStatus: string
{
    case Available = 'available';
    case Unavailable = 'unavailable';
}
